INSERT INTO public."StoreExhibition"(
    "ExhibitionID", "ExhibitionName", "StoreID")
VALUES
    ('a001', 'Exhibition 1', 'a001'),
    ('b002', 'Exhibition 2', 'b002'),
    ('c003', 'Exhibition 3', 'c003'),
    ('d004', 'Exhibition 4', 'd004'),
    ('e005', 'Exhibition 5', 'e005'),
    ('f006', 'Exhibition 6', 'f006'),
    ('g007', 'Exhibition 7', 'g007'),
    ('h008', 'Exhibition 8', 'h008'),
    ('i009', 'Exhibition 9', 'i009'),
    ('j010', 'Exhibition 10', 'j010'),
    ('k011', 'Exhibition 11', 'k011'),
    ('l012', 'Exhibition 12', 'l012'),
    ('m013', 'Exhibition 13', 'm013'),
    ('n014', 'Exhibition 14', 'n014'),
    ('o015', 'Exhibition 15', 'o015'),
    ('p016', 'Exhibition 16', 'p016'),
    ('q017', 'Exhibition 17', 'q017'),
    ('r018', 'Exhibition 18', 'r018'),
    ('s019', 'Exhibition 19', 's019'),
    ('t020', 'Exhibition 20', 't020');
