INSERT INTO public."Publisher"(
    "PublisherID ", "PublisherName", "City", "Country", "Telephone", "YearFounded")
VALUES
    ('a001', 'Alpha Publishing', 'New York', 'USA', '123-456-7890', 1990),
    ('b002', 'Beta Books', 'London', 'UK', '234-567-8901', 1985),
    ('c003', 'Gamma Press', 'Toronto', 'Canada', '345-678-9012', 1975),
    ('d004', 'Delta Publications', 'Sydney', 'Australia', '456-789-0123', 2000),
    ('e005', 'Epsilon Editions', 'Auckland', 'New Zealand', '567-890-1234', 1995),
    ('f006', 'Zeta House', 'Dublin', 'Ireland', '678-901-2345', 1980),
    ('g007', 'Eta Books', 'Berlin', 'Germany', '789-012-3456', 1965),
    ('h008', 'Theta Publishers', 'Paris', 'France', '890-123-4567', 1970),
    ('i009', 'Iota Publishing', 'Rome', 'Italy', '901-234-5678', 1988),
    ('j010', 'Kappa Press', 'Madrid', 'Spain', '012-345-6789', 1992),
    ('k011', 'Lambda Publications', 'Lisbon', 'Portugal', '123-456-7891', 2005),
    ('l012', 'Mu Editions', 'Vienna', 'Austria', '234-567-8902', 1983),
    ('m013', 'Nu House', 'Brussels', 'Belgium', '345-678-9013', 1977),
    ('n014', 'Xi Books', 'Athens', 'Greece', '456-789-0124', 1998),
    ('o015', 'Omicron Publishers', 'Oslo', 'Norway', '567-890-1235', 1991),
    ('p016', 'Pi Press', 'Stockholm', 'Sweden', '678-901-2346', 1968),
    ('q017', 'Rho Editions', 'Helsinki', 'Finland', '789-012-3457', 1982),
    ('r018', 'Sigma Publishing', 'Copenhagen', 'Denmark', '890-123-4568', 2001),
    ('s019', 'Tau Publications', 'Reykjavik', 'Iceland', '901-234-5679', 1997),
    ('t020', 'Upsilon House', 'Zurich', 'Switzerland', '012-345-6790', 1986);
