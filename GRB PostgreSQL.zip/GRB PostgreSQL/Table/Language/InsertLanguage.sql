INSERT INTO public."Language"(
    "LanguageID", "LanguageName")
VALUES
    ('a001', 'English'),
    ('b002', 'Spanish'),
    ('c003', 'French'),
    ('d004', 'German'),
    ('e005', 'Chinese'),
    ('f006', 'Japanese'),
    ('g007', 'Russian'),
    ('h008', 'Portuguese'),
    ('i009', 'Italian'),
    ('j010', 'Korean'),
    ('k011', 'Hindi'),
    ('l012', 'Arabic'),
    ('m013', 'Turkish'),
    ('n014', 'Dutch'),
    ('o015', 'Swedish'),
    ('p016', 'Greek'),
    ('q017', 'Hebrew'),
    ('r018', 'Danish'),
    ('s019', 'Javanese'),
    ('t020', 'Indonesia');
