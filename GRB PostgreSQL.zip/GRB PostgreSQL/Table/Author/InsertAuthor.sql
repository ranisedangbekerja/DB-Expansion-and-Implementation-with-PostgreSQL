INSERT INTO public."Author"(
	"AuthorID", "AuthorName", "YearBorn", "YearDied")
VALUES 
    ('A001', 'Author One', 1950, 2000),
    ('B002', 'Author Two', 1960, 2010),
    ('C003', 'Author Three', 1970, 2020),
    ('D004', 'Author Four', 1980, NULL),
    ('E005', 'Author Five', 1945, 1995),
    ('F006', 'Author Six', 1930, 1980),
    ('G007', 'Author Seven', 1920, 1970),
    ('H008', 'Author Eight', 1910, 1960),
    ('I009', 'Author Nine', 1900, 1950),
    ('J010', 'Author Ten', 1990, NULL),
    ('K011', 'Author Eleven', 2000, NULL),
    ('L012', 'Author Twelve', 1985, NULL),
    ('M013', 'Author Thirteen', 1975, NULL),
    ('N014', 'Author Fourteen', 1965, 2025),
    ('O015', 'Author Fifteen', 1955, 2015),
    ('P016', 'Author Sixteen', 1940, 2000),
    ('Q017', 'Author Seventeen', 1935, 1995),
    ('R018', 'Author Eighteen', 1925, 1985),
    ('S019', 'Author Nineteen', 1915, 1975),
    ('T020', 'Author Twenty', 1905, 1965);