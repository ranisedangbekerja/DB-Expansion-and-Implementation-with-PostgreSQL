INSERT INTO public."Supplier"(
    "SupplierID", "SupplierName")
VALUES
    ('a001', 'Supplier Alpha'),
    ('b002', 'Supplier Beta'),
    ('c003', 'Supplier Gamma'),
    ('d004', 'Supplier Delta'),
    ('e005', 'Supplier Epsilon'),
    ('f006', 'Supplier Zeta'),
    ('g007', 'Supplier Eta'),
    ('h008', 'Supplier Theta'),
    ('i009', 'Supplier Iota'),
    ('j010', 'Supplier Kappa'),
    ('k011', 'Supplier Lambda'),
    ('l012', 'Supplier Mu'),
    ('m013', 'Supplier Nu'),
    ('n014', 'Supplier Xi'),
    ('o015', 'Supplier Omicron'),
    ('p016', 'Supplier Pi'),
    ('q017', 'Supplier Rho'),
    ('r018', 'Supplier Sigma'),
    ('s019', 'Supplier Tau'),
    ('t020', 'Supplier Upsilon');
