INSERT INTO public."Book"(
    "BookID", "BookNumber", "BookName", "PublicationYear ", "Pages", "PublisherID ")
VALUES
    ('1001', 'BN001', 'The Alpha Chronicles', 1990, 320, 'a001'),
    ('2002', 'BN002', 'The Beta Legacy', 1985, 280, 'b002'),
    ('3003', 'BN003', 'Gamma Rising', 1975, 350, 'c003'),
    ('4004', 'BN004', 'Delta Force', 2000, 400, 'd004'),
    ('5005', 'BN005', 'Epsilon Adventures', 1995, 310, 'e005'),
    ('6006', 'BN006', 'Zeta Tales', 1980, 290, 'f006'),
    ('7007', 'BN007', 'Eta Journeys', 1965, 270, 'g007'),
    ('8008', 'BN008', 'Theta Myths', 1970, 340, 'h008'),
    ('9009', 'BN009', 'Iota Legends', 1988, 360, 'i009'),
    ('0010', 'BN010', 'Kappa Stories', 1992, 330, 'j010'),
    ('!011', 'BN011', 'Lambda Chronicles', 2005, 410, 'k011'),
    ('@012', 'BN012', 'Mu Narratives', 1983, 295, 'l012'),
    ('#013', 'BN013', 'Nu Fables', 1977, 285, 'm013'),
    ('$014', 'BN014', 'Xi Epics', 1998, 375, 'n014'),
    ('^015', 'BN015', 'Omicron Sagas', 1991, 325, 'o015'),
    ('%016', 'BN016', 'Pi Accounts', 1968, 310, 'p016'),
    ('*017', 'BN017', 'Rho Records', 1982, 335, 'q017'),
    ('(018', 'BN018', 'Sigma Histories', 2001, 420, 'r018'),
    (')019', 'BN019', 'Tau Recollections', 1997, 300, 's019'),
    ('_020', 'BN020', 'Upsilon Anecdotes', 1986, 310, 't020');
