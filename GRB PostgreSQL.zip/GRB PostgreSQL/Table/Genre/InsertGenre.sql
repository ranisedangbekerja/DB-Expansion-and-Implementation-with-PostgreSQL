INSERT INTO public."Genre"(
    "GenreID", "GenreName", "BookID")
VALUES
    ('a001', 'Fantasy', '!'),
    ('b002', 'Science Fiction', '#'),
    ('c003', 'Mystery', '$'),
    ('d004', 'Thriller', '%'),
    ('e005', 'Romance', '('),
    ('f006', 'Horror', ')'),
    ('g007', 'Historical', '*'),
    ('h008', 'Adventure', '0'),
    ('i009', 'Young Adult', '1'),
    ('j010', 'Children', '2'),
    ('k011', 'Non-Fiction', '3'),
    ('l012', 'Biography', '4'),
    ('m013', 'Self-Help', '5'),
    ('n014', 'Health', '6'),
    ('o015', 'Travel', '7'),
    ('p016', 'Guide', '8'),
    ('q017', 'Poetry', '9'),
    ('r018', 'Drama', '@'),
    ('s019', 'Classic', '^'),
    ('t020', 'Humor', '_');
