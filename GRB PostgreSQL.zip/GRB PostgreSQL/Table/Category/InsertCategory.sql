INSERT INTO public."Category"(
    "CategoryID", "CategoryName", "BookID")
VALUES
    ('a001', 'Fiction', '!'),
    ('b002', 'Science', '#'),
    ('c003', 'History', '$'),
    ('d004', 'Biography', '%'),
    ('e005', 'Mystery', '('),
    ('f006', 'Fantasy', ')'),
    ('g007', 'Romance', '*'),
    ('h008', 'Thriller', '0'),
    ('i009', 'Horror', '1'),
    ('j010', 'Adventure', '2'),
    ('k011', 'Science Fiction', '3'),
    ('l012', 'Poetry', '4'),
    ('m013', 'Drama', '5'),
    ('n014', 'Classic', '6'),
    ('o015', 'Humor', '7'),
    ('p016', 'Non-Fiction', '8'),
    ('q017', 'Children', '9'),
    ('r018', 'Young Adult', '@'),
    ('s019', 'Travel', '^'),
    ('t020', 'Self-Help', '_');
