INSERT INTO public."Review"(
    "ReviewID", "UserID", "BookID", "Rating", "Comment", "Date")
VALUES
    ('r001', 'u001', '!', 5, 'Great book!', '2024-01-10'),
    ('s002', 'v002', '#', 4, 'Very interesting read.', '2024-01-11'),
    ('t003', 'w003', '$', 3, 'It was okay.', '2024-01-12'),
    ('u004', 'x004', '%', 2, 'Not what I expected.', '2024-01-13'),
    ('v005', 'y005', '(', 1, 'Did not like it at all.', '2024-01-14'),
    ('w006', 'z006', ')', 5, 'Absolutely loved it!', '2024-01-15'),
    ('x007', 'a007', '*', 4, 'Great, but could be better.', '2024-01-16'),
    ('y008', 'b008', '0', 3, 'Just average.', '2024-01-17'),
    ('z009', 'c009', '1', 2, 'Not my type.', '2024-01-18'),
    ('a010', 'd010', '2', 1, 'Terrible.', '2024-01-19'),
    ('b011', 'e011', '3', 5, 'A must-read!', '2024-01-20'),
    ('c012', 'f012', '4', 4, 'Really good.', '2024-01-21'),
    ('d013', 'g013', '5', 3, 'It was fine.', '2024-01-22'),
    ('e014', 'h014', '6', 2, 'Could be better.', '2024-01-23'),
    ('f015', 'i015', '7', 1, 'Not worth my time.', '2024-01-24'),
    ('g016', 'j016', '8', 5, 'Loved every bit of it.', '2024-01-25'),
    ('h017', 'k017', '9', 4, 'Quite good.', '2024-01-26'),
    ('i018', 'l018', '@', 3, 'Average book.', '2024-01-27'),
    ('j019', 'm019', '^', 2, 'Did not enjoy it.', '2024-01-28'),
    ('k020', 'n020', '_', 1, 'Really bad.', '2024-01-29');
