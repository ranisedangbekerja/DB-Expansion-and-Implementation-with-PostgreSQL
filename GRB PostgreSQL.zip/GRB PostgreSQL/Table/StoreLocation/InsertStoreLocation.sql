INSERT INTO public."StoreLocation"(
    "StoreID", "StoreName", "Address", "City", "Coutry", "PhoneNumber")
VALUES
    ('a001', 'Alpha Books', '123 Alpha St', 'New York', 'USA', 1290),
    ('b002', 'Beta Books', '456 Beta Ave', 'London', 'UK', 2301),
    ('c003', 'Gamma Books', '789 Gamma Blvd', 'Toronto', 'Canada', 3456),
    ('d004', 'Delta Books', '101 Delta Rd', 'Sydney', 'Australia', 4563),
    ('e005', 'Epsilon Books', '202 Epsilon Ln', 'Auckland', 'New Zealand', 5634),
    ('f006', 'Zeta Books', '303 Zeta Pl', 'Dublin', 'Ireland', 6789),
    ('g007', 'Eta Books', '404 Eta Ct', 'Berlin', 'Germany', 7890),
    ('h008', 'Theta Books', '505 Theta Dr', 'Paris', 'France', 8901),
    ('i009', 'Iota Books', '606 Iota Blvd', 'Rome', 'Italy', 9012),
    ('j010', 'Kappa Books', '707 Kappa St', 'Madrid', 'Spain', 1234),
    ('k011', 'Lambda Books', '808 Lambda Ave', 'Lisbon', 'Portugal', 7891),
    ('l012', 'Mu Books', '909 Mu Rd', 'Vienna', 'Austria', 2345),
    ('m013', 'Nu Books', '1010 Nu Ln', 'Brussels', 'Belgium', 3456),
    ('n014', 'Xi Books', '1111 Xi Pl', 'Athens', 'Greece', 4124),
    ('o015', 'Omicron Books', '1212 Omicron Ct', 'Oslo', 'Norway', 5678),
    ('p016', 'Pi Books', '1313 Pi Dr', 'Stockholm', 'Sweden', 6786),
    ('q017', 'Rho Books', '1414 Rho Blvd', 'Helsinki', 'Finland', 7457),
    ('r018', 'Sigma Books', '1515 Sigma St', 'Copenhagen', 'Denmark', 8908),
    ('s019', 'Tau Books', '1616 Tau Ave', 'Reykjavik', 'Iceland', 9679),
    ('t020', 'Upsilon Books', '1717 Upsilon Rd', 'Zurich', 'Switzerland', 1200);
