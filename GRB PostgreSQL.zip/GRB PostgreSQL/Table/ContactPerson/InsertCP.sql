INSERT INTO public."ContactPerson"(
    "StaffID", "StaffName", "Phone", "StoreID")
VALUES
    ('a001', 'Alice Johnson', 1234, 'a001'),
    ('b002', 'Bob Smith', 2346, 'b002'),
    ('c003', 'Charlie Brown', 3456, 'c003'),
    ('d004', 'David Williams', 4568, 'd004'),
    ('e005', 'Eva Davis', 5678, 'e005'),
    ('f006', 'Frank Miller', 6789, 'f006'),
    ('g007', 'Grace Wilson', 7890, 'g007'),
    ('h008', 'Hannah Moore', 8901, 'h008'),
    ('i009', 'Ian Taylor', 9012, 'i009'),
    ('j010', 'Julia Anderson', 1234, 'j010'),
    ('k011', 'Kevin Thomas', 1234, 'k011'),
    ('l012', 'Lily Martinez', 2345, 'l012'),
    ('m013', 'Mike Garcia', 3456, 'm013'),
    ('n014', 'Nina Rodriguez', 4564, 'n014'),
    ('o015', 'Oscar Martinez', 5675, 'o015'),
    ('p016', 'Paul Hernandez', 6786, 'p016'),
    ('q017', 'Quinn Lopez', 7897, 'q017'),
    ('r018', 'Rachel Lee', 8908, 'r018'),
    ('s019', 'Sam Walker', 5679, 's019'),
    ('t020', 'Tina Hall', 1790, 't020');
