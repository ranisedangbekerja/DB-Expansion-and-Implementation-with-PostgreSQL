INSERT INTO public."UserAccount"(
    "UserID", "Username", "Password", "Email", "DateCreated")
VALUES
    ('u001', 'user1', 'password1', 'user1@example.com', '2024-01-01'),
    ('v002', 'user2', 'password2', 'user2@example.com', '2024-01-02'),
    ('w003', 'user3', 'password3', 'user3@example.com', '2024-01-03'),
    ('x004', 'user4', 'password4', 'user4@example.com', '2024-01-04'),
    ('y005', 'user5', 'password5', 'user5@example.com', '2024-01-05'),
    ('z006', 'user6', 'password6', 'user6@example.com', '2024-01-06'),
    ('a007', 'user7', 'password7', 'user7@example.com', '2024-01-07'),
    ('b008', 'user8', 'password8', 'user8@example.com', '2024-01-08'),
    ('c009', 'user9', 'password9', 'user9@example.com', '2024-01-09'),
    ('d010', 'user10', 'password10', 'user10@example.com', '2024-01-10'),
    ('e011', 'user11', 'password11', 'user11@example.com', '2024-01-11'),
    ('f012', 'user12', 'password12', 'user12@example.com', '2024-01-12'),
    ('g013', 'user13', 'password13', 'user13@example.com', '2024-01-13'),
    ('h014', 'user14', 'password14', 'user14@example.com', '2024-01-14'),
    ('i015', 'user15', 'password15', 'user15@example.com', '2024-01-15'),
    ('j016', 'user16', 'password16', 'user16@example.com', '2024-01-16'),
    ('k017', 'user17', 'password17', 'user17@example.com', '2024-01-17'),
    ('l018', 'user18', 'password18', 'user18@example.com', '2024-01-18'),
    ('m019', 'user19', 'password19', 'user19@example.com', '2024-01-19'),
    ('n020', 'user20', 'password20', 'user20@example.com', '2024-01-20');
