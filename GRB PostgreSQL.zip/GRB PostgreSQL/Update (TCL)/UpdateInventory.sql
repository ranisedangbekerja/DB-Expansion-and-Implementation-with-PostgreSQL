UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '!';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '#';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '$';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '%';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '(';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = ')';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '*';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '0';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 2
WHERE "BookID" = '1';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '2';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 4
WHERE "BookID" = '3';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '4';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '5';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '6';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '7';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '8';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '9';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 3
WHERE "BookID" = '@';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '^';

UPDATE public."Inventory"
SET "Quantity" = "Quantity" - 1
WHERE "BookID" = '_';
